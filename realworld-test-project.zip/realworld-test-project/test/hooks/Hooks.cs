﻿/**
* @author Ivan Jakovljevic (ivan_jakovljevic@outlook.com)
* @since 7/31/2020
*/
namespace realworld.test.hooks
{
    //TODO: Implement methods for logical deletation of created test data after successfull execution of test scenarios. (Missing DB access)

    public class Hooks
    {
    }
}
